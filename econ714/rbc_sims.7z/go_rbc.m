% RBC model from Erik Sims' lecture notes:
% http://www3.nd.edu/~esims1/using_dynare_sp16.pdf

%% Initialize parameters and run Dynare
clear all;
close all;

% specify parameters
beta = 0.99;
alpha = 1/3;
sigma = 1;
sigmae = 0.01;
rho = 0.95;
delta = 0.025;

save param_rbc alpha beta delta rho sigma sigmae

% execute a Dynare file
dynare rbc noclearall nolog

%% Post-estimation
% Manually compute and plot IRF's and simulations

p_y = 1;
p_I = 2;
p_k = 3;
p_a = 4;
p_c = 5;
p_w = 6;
p_R = 7;
p_r = 8;

% state space representation: 
% S(t) = A * S(t-1) + B * e(t)
% X(t) = C * S(t-1) + D * e(t);

A = [oo_.dr.ghx(oo_.dr.inv_order_var(p_k),:);
oo_.dr.ghx(oo_.dr.inv_order_var(p_a),:)];

B = [oo_.dr.ghu(oo_.dr.inv_order_var(p_k),:);
oo_.dr.ghu(oo_.dr.inv_order_var(p_a),:)];

C = [oo_.dr.ghx(oo_.dr.inv_order_var(p_y),:);
oo_.dr.ghx(oo_.dr.inv_order_var(p_I),:);
oo_.dr.ghx(oo_.dr.inv_order_var(p_c),:);
oo_.dr.ghx(oo_.dr.inv_order_var(p_w),:);
oo_.dr.ghx(oo_.dr.inv_order_var(p_R),:);
oo_.dr.ghx(oo_.dr.inv_order_var(p_r),:)];

D = [oo_.dr.ghu(oo_.dr.inv_order_var(p_y),:);
oo_.dr.ghu(oo_.dr.inv_order_var(p_I),:);
oo_.dr.ghu(oo_.dr.inv_order_var(p_c),:);
oo_.dr.ghu(oo_.dr.inv_order_var(p_w),:);
oo_.dr.ghu(oo_.dr.inv_order_var(p_R),:);
oo_.dr.ghu(oo_.dr.inv_order_var(p_r),:)];

% compute impulse responses by hand
H = 20;
Sirf = zeros(2,H);
Xirf = zeros(6,H);

Sirf(:,1) = B * sigmae;
Xirf(:,1) = D * sigmae;

for j = 2:H
Sirf(:,j) = A * Sirf(:,j-1);
Xirf(:,j) = C * Sirf(:,j-1);
end

% compute a simulation. First draw shocks
randn('seed',666)
T = 200; % number of periods to simulate
e = sigmae * randn(1,T);

Ssim = zeros(2,T);
Xsim = zeros(6,T);

% assume initial state is SS
Ssim(:,1) = B * e(1,1);
for j = 2:T
Ssim(:,j) = A * Ssim(:,j-1) + B * e(1,j);
Xsim(:,j) = C * Ssim(:,j-1) + D * e(1,j);
end

% plot
figure;
subplot(2,1,1);
plot(Ssim(2,:));
title('a');
subplot(2,1,2);
plot(Ssim(1,:));
title('k');