%% Kalman filter demo.
% By Anton Babkin, made on his 30th birthday.

format compact;
cd('your_folder_with_this_file_and_logL.m');

%% One update iteration
% This example uses notation and parametrization from:
% http://quant-econ.net/py/kalman.html
clear; 
clc;

pause('on');

% prior
xhat = [0.2; 0.2];
Sigma = [0.4, 0.3; 0.3, 0.45];

xlim = [-1.5; 3.5];
ylim = [-3; 2];
ngrid = 50;
xgrid = linspace(xlim(1), xlim(2), ngrid);
ygrid = linspace(ylim(1), ylim(2), ngrid);
[x, y] = meshgrid(xgrid, ygrid);
z = mvnpdf([x(:), y(:)], xhat', Sigma);
[C, h1] = contour(x, y, reshape(z, size(x)), 'k');
hold on;
pause;

% signal
yf = [2.3; -1.9];
plot(yf(1), yf(2), 'r-o', 'MarkerFaceColor', 'r');
pause;

% filter
G = eye(2);
R = 0.5 * Sigma;

s_ = Sigma*G'/(G*Sigma*G'+R);
xf = xhat + s_*(yf-G*xhat);
Sigmaf = Sigma - s_*G*Sigma;

z = mvnpdf([x(:), y(:)], xf', Sigmaf);
[C, hf] = contour(x, y, reshape(z, size(x)), 'r');
pause;

% predict
A = [1.2, 0; 0, -0.2];
Q = 0.3 * Sigma;
xn = A*xf;
Sigman = A*Sigmaf*A' + Q;
plot([xf(1); xn(1)], [xf(2); xn(2)], 'b--x');
pause;

z = mvnpdf([x(:), y(:)], xn', Sigman);
[C, hn] = contour(x, y, reshape(z, size(x)), 'b');
pause;

h1.LineStyle = '--';
hf.LineStyle = '--';
hn.LineColor = 'k';
pause;

% new signal
plot(3, 1.5, 'r-o', 'MarkerFaceColor', 'r');
hold off;

%% Iterative over multiple periods 
% Now let's use Kalman filtering to form beliefs about trajectory of a
% plane that flies from Moscow, Russia to New York city, USA. Actual
% trajectory is not observed, but there is a noisy radar reading about it.

% Actual process:
% X_{t+1} = A * X_t + v_{t+1}
% where X_t is 2x1 vector and v_t ~ N(mA, sA)

% Noisy signal:
% y_t = B * X_t + u_t
% where y_t is 2x1 and u_t ~ N(0, sB)

clear; 
clc;

% Parameters
T = 5;
ssA = 2; % scale of sA
ssB = 1; % scale of sB
kappa = 2;

% Determenistic process for X_t is a parabola going through 3 points in
% "route" variables, and x-coordinate takes constant steps dx.
% You can safely ignore this section: it's just a way to construct a
% trajectory parameters A and mA.
xroute = [620, 350, 170];
yroute = [110, 100, 200];
p = polyfit(xroute, yroute, 2);
dx = (xroute(end) - xroute(1)) / (T-1);
adx = abs(dx);
A = eye(2);
A(2,1) = 2*p(1)*dx;
mA = [dx; p(1)*dx^2+p(2)*dx];
sA = ssA * adx * eye(2);
B = eye(2);
sB = ssB * adx * eye(2);

% declare variables
x0t = zeros(2, T); % deterministic X_t
xt = zeros(2, T); % actual X_t
yt = zeros(2, T); % signal y_t
xft = zeros(2, T); % filtered X_t
Sxft = zeros(2, 2, T); % filtered variance of X_t
xpt = zeros(2, T); % prediction of X_t
Sxpt = zeros(2, 2, T); % prediction variance of X_t
ypt = zeros(2, T); % prediction of y_t
Syt = zeros(2, 2, T); % prediction variance of y_t
eyt = zeros(2, T); % prediction errors of y_t

% initial state
x0t(:, 1) = [xroute(1); yroute(1)];
xt(:, 1) = mvnrnd(x0t(:, 1), sA)';

% actual process
for t = 1:T
    x = xt(:,t);
    yt(:,t) = B*x + mvnrnd([0;0], sB)';
    if t < T
        x0t(:,t+1) = A*x0t(:,t) + mA;
        xt(:,t+1) = A*x + mvnrnd(mA, sA)';
    end
end

% initial prior
xpt(:,1) = x0t(:,1);
Sxpt(:,:,1) = kappa * adx * eye(2);

% predicting
for t=1:T
    xp_ = xpt(:,t);
    Sxp_ = Sxpt(:,:,t);
    y = yt(:,t);
    
    % predict y
    yp = B*xp_;
    Sy = B*Sxp_*B'+sB;
    ey = y - yp;
    % filter
    xf = xp_ + Sxp_*B'/Sy*ey;
    Sxf = Sxp_ - Sxp_*B'/Sy*B*Sxp_;
    % predict X
    xp = A*xf + mA;
    Sxp = A*Sxf*A' + sA;
    
    ypt(:,t) = yp;
    Syt(:,:,t) = Sy;
    eyt(:,t) = ey;
    xft(:,t) = xf;
    Sxft(:,:,t) = Sxf;
    if t < T
        xpt(:,t+1) = xp;
        Sxpt(:,:,t+1) = Sxp;
    end
end

%% Visualization of the trajectory, signal filtering and prior updates
pause('on');

m = imread('map.png');
m = round(double(m)/255 * 63) + 1;
m1 = m(1:300,100:800);
image(m1, 'AlphaData', 0.5);
hold on;
pause;

plot(x0t(1,:),x0t(2,:), 'g:x', 'LineWidth', 2);
pause;
plot(xt(1,:),xt(2,:), 'g--x', 'LineWidth', 2);
pause;

ngrid = 20;
for t=1:T
    % prior
    x = xpt(1,t);
    y = xpt(2,t);
    S = Sxpt(:,:,t);
    
    if t>1
        plot([xft(1,t-1); x], [xft(2,t-1);y], 'b--');
    end
    xgrid = linspace(x-0.5*adx, x+0.5*adx, ngrid);
    ygrid = linspace(y-0.5*adx, y+0.5*adx, ngrid);
    [xmesh, ymesh] = meshgrid(xgrid, ygrid);
    z = mvnpdf([xmesh(:), ymesh(:)], [x, y], S);
    contour(xmesh, ymesh, reshape(z, size(xmesh)), 2, 'k');
    pause;
    
    % signal
    plot(yt(1,t),yt(2,t), 'ro', 'MarkerFaceColor', 'r');
    pause;
    
    % filter
    x = xft(1,t);
    y = xft(2,t);
    S = Sxft(:,:,t);
    xgrid = linspace(x-0.5*adx, x+0.5*adx, ngrid);
    ygrid = linspace(y-0.5*adx, y+0.5*adx, ngrid);
    [xmesh, ymesh] = meshgrid(xgrid, ygrid);
    z = mvnpdf([xmesh(:), ymesh(:)], [x, y], S);
    contour(xmesh, ymesh, reshape(z, size(xmesh)), 2, 'r');
    pause;    
end

hold off

%% Inference
% Pretend that we only observe signal realizations, have a t=1 prior, know
% the model and all the parameters except mA(1).
% We can estimate mA(1) with MLE.

image(m1, 'AlphaData', 0.2);
hold on;

plot(x0t(1,:),x0t(2,:), 'g:x', 'LineWidth', 2);
plot(yt(1,:),yt(2,:), 'ro', 'MarkerFaceColor', 'r');

% alternative mA(1) parameter values
% mA = [dx; p(1)*dx^2+p(2)*dx];
mA
mA_ = mA;
mA_(1) = 0.8*dx
x0t_ = zeros(2, T);
x0t_(:, 1) = [xroute(1); yroute(1)];
for t = 1:T-1
    x0t_(:,t+1) = A*x0t_(:,t) + mA_;
end
plot(x0t_(1,:),x0t_(2,:), 'm:x', 'LineWidth', 2);

mA_ = mA;
mA_(1) = 1.2*dx
x0t_ = zeros(2, T);
x0t_(:, 1) = [xroute(1); yroute(1)];
for t = 1:T-1
    x0t_(:,t+1) = A*x0t_(:,t) + mA_;
end
plot(x0t_(1,:),x0t_(2,:), 'm:x', 'LineWidth', 2);

ngrid = 20;
for t=1:T
    % prior
    x = xpt(1,t);
    y = xpt(2,t);
    S = Sxpt(:,:,t);

    xgrid = linspace(x-0.5*adx, x+0.5*adx, ngrid);
    ygrid = linspace(y-0.5*adx, y+0.5*adx, ngrid);
    [xmesh, ymesh] = meshgrid(xgrid, ygrid);
    z = mvnpdf([xmesh(:), ymesh(:)], [x, y], S);
    contour(xmesh, ymesh, reshape(z, size(xmesh)), 2, 'k');
end
hold off

% MLE estimation of "unknown" parameter mA(1)
% grid search
N = 50;
L = zeros(N,1);
th=linspace(-200,0,N);
f = @(theta) -logL(2,ssA,ssB,A,[theta; mA(2)],B,adx,T,yt,x0t(:,1),kappa * adx * eye(2));
for i=1:N
    L(i) = f(th(i));
end
figure;
plot(th, -L)
[v,i] = max(-L);
th(i)

% numerical MATLAB optimization
fminunc(f, -150)
