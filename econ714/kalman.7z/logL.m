function [ L ] = logL(m, ssA, ssB, A, mA, B, adx, T, yt, xp1, Sxp1)
%LOGL Log-likelihood function for MLE estimation
%   For Kalman filter example.
%   See Canova (2007), section 6.2, equation 6.22.

sA = ssA * adx * eye(m);
sB = ssB * adx * eye(m);

% series
xpt = zeros(m, T); % prediction of X_t
Sxpt = zeros(m, m, T); % prediction variance of X_t
Syt = zeros(m, m, T); % prediction variance of y_t
eyt = zeros(m, T); % prediction errors of y_t

% initial prior
xpt(:,1) = xp1;
Sxpt(:,:,1) = Sxp1;

% predicting
for t=1:T
    xp_ = xpt(:,t);
    Sxp_ = Sxpt(:,:,t);
    y = yt(:,t);
    
    % predict y
    yp = B*xp_;
    Sy = B*Sxp_*B'+sB;
    ey = y - yp;
    % filter
    xf = xp_ + Sxp_*B'/Sy*ey;
    Sxf = Sxp_ - Sxp_*B'/Sy*B*Sxp_;
    % predict X
    xp = A*xf + mA;
    Sxp = A*Sxf*A' + sA;
    
    Syt(:,:,t) = Sy;
    eyt(:,t) = ey;
    if t < T
        xpt(:,t+1) = xp;
        Sxpt(:,:,t+1) = Sxp;
    end
end

% calculate log-likelihood
L = T*m*log(2*pi);
for t=1:T
    L = L + log(det(Syt(:,:,t))) + ...
        eyt(:,t)'/Syt(:,:,t)*eyt(:,t);
end
L = -0.5 * L;

end

