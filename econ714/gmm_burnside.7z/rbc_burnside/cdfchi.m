function y=cdfchi(x,d)
y=gammainc(x/2,d/2) ;
