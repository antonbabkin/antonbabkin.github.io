function y=cdfn(x)
y=(1+erf(x/sqrt(2)))/2 ;
