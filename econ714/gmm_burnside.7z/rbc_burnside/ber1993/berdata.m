function dm=berdata(b)

dm=b(13:17,1) ;
