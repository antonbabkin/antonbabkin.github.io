function y=cdfnc(x)
y=(1-erf(x/sqrt(2)))/2 ;
