function y=cdfchic(x,d)
y=1-gammainc(x/2,d/2) ;
