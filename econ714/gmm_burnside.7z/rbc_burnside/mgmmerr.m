function m=mgmmerr(b0)
m=mean(gmmerr(b0))' ;
