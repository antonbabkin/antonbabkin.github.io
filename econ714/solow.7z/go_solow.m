% Dynare example: Stochastic Solow growth model.
% By Anton Babkin. 18 mar 2016.

%% Solving model in Dynare
dynare solow

%% Post-estimation
% Plot simulated data
figure;
plot(exp(oo_.endo_simul'));
legend(M_.endo_names);